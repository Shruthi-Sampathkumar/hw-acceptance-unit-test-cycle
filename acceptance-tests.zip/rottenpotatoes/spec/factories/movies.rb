FactoryBot.define do

  factory :movie do
  end
end 